Nome: Luccas da Silva Lima
Matrícula: 00324683
Turma: A

Nome: Henrique Carniel da Silva
Matrícula: 00335626
Turma: A